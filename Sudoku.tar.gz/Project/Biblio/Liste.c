#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#include "Liste.h"


Liste* remplissageListe(int n) {
    Liste* liste = malloc(sizeof(Liste));
    Element * element = malloc(sizeof(Element));
    liste->premier = element;

    for (int i = 1; i<=n; i++) {
        element->nombre = i;
        if (i == n) element->suivant = NULL;
        else {
            element->suivant = malloc(sizeof(Element));
            element = element->suivant;
        }
    }
    return liste;
}

void affichageListe(Liste *l) {
    Element * element;
    printf("affichage de la liste \n");
    element = l->premier;
    while(element != NULL) {
        printf("%d ", element->nombre);
        element = element->suivant;
    }
    printf("\n");
}

int tassageListe(Liste *l, int n) {
    int x = 0;
    Element *element = l->premier;
    for (int i = 0; i<n-2;i++) {
        element= element->suivant;
    }
    if (element->suivant == NULL) {
        x = l->premier->nombre;
        l->premier = NULL;
        return x;
    }
    if (n == 1) {
        x = l->premier->nombre;
        l->premier = element->suivant;
        return x;
    }
    x = element->suivant->nombre;
    element->suivant = element->suivant->suivant;
    return x;
}

Liste * generateListe(int n, float taux) {
	Liste *remplissageListe(int n);
	int tassageListe(Liste *l, int n);
	Liste *liste = remplissageListe(n*n);
    srand(time(0));
	int k = 0, i, t = n*n;
	while (k < n*n * taux) {
		i = rand() % (t) + 1;
		tassageListe(liste, i);
		t--;k++;
	}
	return liste;
}