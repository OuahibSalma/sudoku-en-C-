#ifndef LISTE_H
#define LISTE_H

typedef struct Element Element;
struct Element{
	int nombre;
	Element* suivant;	
};

typedef struct {
	Element* premier;
}Liste;

// Liste des valeurs possible !
Liste* remplissageListe(int ) ;

void affichageListe(Liste *) ;

int tassageListe(Liste *, int ) ;

Liste * generateListe(int , float );

#endif /* LISTE_H */