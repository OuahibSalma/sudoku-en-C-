#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#include "Sudoku.h"
#include "Liste.h"

Suduku* initialisation0(int taille ) { 
	Case* p= malloc(sizeof(Case)) ; 
	Suduku* s = malloc(sizeof(Suduku)) ; 
	s->premier = p ;   
	int i , j , k , r ; 
	for(i=1 ; i<=taille ; i++) { 
		if(i <= sqrt(taille)) r = 1 ; 
		else if(i>sqrt(taille) && i<=2*sqrt(taille)) r = sqrt(taille)+1; 
		else if(i>sqrt(taille) && i<=3*sqrt(taille)) r= 2*sqrt(taille)+1 ; 
		else r= 3*sqrt(taille)+1 ;
		k=1 ;  
		for(j=1 ; j<=taille ; j++) {
			p->colonne=j ; 
			p->ligne = i ; 
			p->valeur = 0 ; 
			if(k>sqrt(taille)) { 
				r++ ; 				
				k=1;
			}	 
			if(k<=sqrt(taille)) { 
				p->region = r ; 
				k++; 
			} 
			if(i==taille && j==taille) p->suivant = NULL ; 
			else { 
				p->suivant=malloc(sizeof(Case)) ; 
				p=p->suivant ; 
			}
		} 
	} 
	return s ;   
} 

void ligne(int n ) { 
	int i ;  
	//selon la taille de la matrice , gerer le nombre de tri . 
	printf("\n\t") ; 
	for(i=0 ; i<5*n;i++) printf("-") ; 
	printf("----\n") ; 
}

/*void remplissage( Suduku* liste, int taux, int N   ) {
    Case* element1=liste->premier ;
   int c=1  , j  , i ;
   while( c<=taux ) {
    i= (rand()%N)+1 ;
    j= (rand()%N)+1 ;
    while( element1->ligne !=i && element1->colonne !=j ) {
    element1=element1->suivant ;
    } 
    	  element1->valeur= (rand()%N)+1 ; 
    	   c++ ;
	} 
   }
*/ 

void interface(Suduku s , int n ) { 
    Case* p ; 
    int i=1 , j=0; 
    int k = 1 ;
    p=s.premier ; 
    ligne(n) ;
    while(p!=NULL) {
        if(p->colonne==1) printf("\n\t|   ") ; 
        printf("%d   " , p->valeur ) ;
        if(p->colonne==n) i++ ; 
        p=p->suivant ;
        j++ ;
        if(j==sqrt(n)) {
           j= 0 ; 
                   printf("|   ") ;
    } 
    if(i>sqrt(n)) { 
    ligne(n) ;
    i=1;
    }
    }
} 

void interfaceModifie(Suduku s , int n, float taux ) { 
    Case* p ;
	Liste *liste = generateListe(n, taux);
	Element *element = liste->premier;
	void affichageListe(Liste *l);
    int i=1 , j=0, count = 1; 
    p=s.premier ; 
    ligne(n) ;
    while(p!=NULL) {
        if(p->colonne==1) printf("\n\t|   ") ;
		if (count == element->nombre) {
			printf("%d   " , p->valeur );
			if (element->suivant !=NULL) element = element->suivant;
		}
		else printf("0   ");
        if(p->colonne==n) i++ ; 
        p=p->suivant ;
		
		count++;
        j++;
        if(j==sqrt(n)) {
            j= 0 ; 
            printf("|   ") ;
   		} 
		if(i>sqrt(n)) { 
		ligne(n) ;
		i=1;
		}
    }
} 

int estLigne(Suduku* l , int n , int ligne , int x ) { 
	// Work
	Case* p=l->premier ; 
	int i = 1  , j=1 ; 
	while(p->ligne!=ligne) p = p->suivant; 
	while(j<=n) { 
		if(p->valeur==x) { 
			return 1;
		} 
		p = p->suivant;
		j++; 	
	}
	return 0 ; 
}

int estColonne(Suduku* l , int n , int c , int x) { 
	// Work
	Case* p=l->premier ; 
	
	while(p != NULL) {
		if (p->colonne == c) {
			if(p->valeur==x) return 1;
		}  
		p=p-> suivant ;  
	}
	return 0 ; 	
} 
 
int estRegion(Suduku* s , int r , int x ) { 
	// Work
	Case* p = s->premier ; 
	while(p!=NULL) { 
		if(p->region==r) { 
			if(p->valeur==x) { 
				return 1 ; 
			}
		} 
	p=p->suivant ; 	
	} 
	return 0 ;  
} 

int remplissage(int n , Suduku* l ) {  
	// Work
	void afficherTab(int *tab, int taille), affichageListe(Liste *l);
	int x , r , c=1 , d,j, k, tassageListe(Liste *l, int n), test = 0; 
	Case* p  ; 
	Liste *liste1 ,* remplissageListe(int n);
	p = l->premier;
	for( int i = 0; i<n; i++) {
		for (int j  = 0; j<n; j++) {
			liste1 = remplissageListe(n);
			k = n;
			do {
				if (k == 0) return 0;
				d = (rand() % k) + 1;
				x = tassageListe(liste1, d);
				k--;
			}while (estLigne(l, n, p->ligne, x) || estColonne(l, n, p->colonne, x) || estRegion(l, p->region ,x ));
			p->valeur = x;
			p = p->suivant;
		}
	}
	return 1;	
} 

void afficherTab(int *tab, int taille) {
	printf("affichage du tableau des valeurs possible \n");
	for(int i = 0;i<taille;i++) {
		printf("%d ", *(tab + i));
	}
	printf("\n");
}
