#ifndef SUDOKU_H
#define SUDOKU_H

typedef struct Case Case ; 
struct Case { 
	int ligne ;
	int colonne ; 
	int region ; 
	int valeur ; 
	Case* suivant ;  
}; 
typedef struct  { 
	Case* premier ; 
}Suduku; 

Suduku* initialisation0(int taille );

void ligne(int n ) ;

//void remplissage( Suduku* liste, int taux, int N   ) ;

void interface(Suduku s , int n ) ;

void interfaceModifie(Suduku s , int n, float taux ) ;

int estColonne(Suduku* l , int n , int c , int x) ;
 
int estRegion(Suduku* s , int r , int x ) ;

int remplissage(int n , Suduku* l ) ;

void afficherTab(int *tab, int taille) ;

#endif