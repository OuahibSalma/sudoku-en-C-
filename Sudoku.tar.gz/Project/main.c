#include<stdio.h> 
#include<stdlib.h> 
#include<math.h>
#include<time.h> 

#include "Biblio/Liste.h"
#include "Biblio/Sudoku.h"

int main() { 
	printf("\n\n");
	printf("**************************************** \n");
	printf("*****    Bienvenu au jeux sudoku ! ***** \n");
	printf("**************************************** \n");
	int i = 0, n;
	char rep, buffer;
	float taux; 
	printf("Veuillez choisir le niveau de difficulte : ") ; 
	scanf("%d" , &n) ; 
	Suduku* s ;  
	srand(time(NULL));
	s= initialisation0(n) ;
	while(!(remplissage(n, s))) {
		s= initialisation0(n) ;
	}
	printf("Veuillez saisir le taux de remplissage(25 - 50 - 75 ) pour cent : " ) ;
	scanf("%f", &taux); 
	printf("Voici le sudoku a resoudre, bonne change \n");
	interfaceModifie(*s, n, taux/100);
	do{ 
		scanf("%c", &buffer);
		printf("Est ce que vous voulez voir la solution , repondez avec O/N :" ) ; 
		scanf("%c" , &rep) ; 
	}while(rep!='O') ;
	printf("Voici la solution du sudoku \n");
	interface(*s , n ) ; 	
	return 0 ; 
} 



